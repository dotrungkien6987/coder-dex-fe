export const BASE_URL = process.env.REACT_APP_BACKEND_API;
export const POKEMONS_PER_PAGE = 20;