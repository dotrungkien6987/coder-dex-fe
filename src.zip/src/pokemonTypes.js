export const pokemonTypes = ['bug', 'dragon', 'fairy', 'fire', 'ghost', 'ground', 'normal', 'psychic', 'steel', 'dark', 'electric', 'fighting', 'flying', 'grass', 'ice', 'poison', 'rock', 'water'];
